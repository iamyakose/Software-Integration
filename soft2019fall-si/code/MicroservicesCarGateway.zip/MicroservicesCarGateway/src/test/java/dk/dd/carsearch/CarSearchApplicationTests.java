package dk.dd.carsearch;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarSearchApplicationTests {

    @Test
    void contextLoads() {
    }

}
