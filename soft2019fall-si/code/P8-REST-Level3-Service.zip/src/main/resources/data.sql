insert into student values(101,'Alice', 'Alice', 'al@mail.dk');
insert into student values(102,'Bob', 'Bobby', 'bo@mail.dk');
insert into message values(23, 'Boot is good', 102);