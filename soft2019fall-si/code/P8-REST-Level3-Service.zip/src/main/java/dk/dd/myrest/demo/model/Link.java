package dk.dd.myrest.demo.model;
// Custom class Link, instead of Java class Link
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Link
{
    private String link;
    private String rel;

}
