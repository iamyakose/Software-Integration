package dk.dd.myrest.demo.controller;

import dk.dd.myrest.demo.exceptions.ResourceNotFoundException;
import dk.dd.myrest.demo.model.Message;
import dk.dd.myrest.demo.model.Student;
import dk.dd.myrest.demo.repo.MessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resource;
import org.springframework.hateoas.Resources;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.web.bind.annotation.*;


import javax.validation.Valid;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.*;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;

@RestController
@RequestMapping("/messages")
//@RequestMapping("/") // if it comes from Student
public class MessageController
{
    @Autowired
    private MessageRepository mrepo;
    private Object Message;

    List<Message> messages;

    public MessageController() {
        messages = new LinkedList<>();
        messages.add(new Message(1, "Info", 101));
        messages.add(new Message(2, "Question", 102));
    }

    @GetMapping(value = "/all", produces = "application/hal+json")
    public Resources<Resource> getMessages() throws ResourceNotFoundException {
        List<Link> links = new LinkedList<>();
        links.add(linkTo(methodOn(MessageController.class).getMessages()).withSelfRel());
        List<Resource> resources = messageToResource(messages.toArray(new Message[0]));
        return new Resources<>(resources, links);
    }

    private List<Resource> messageToResource(Message... Messages) throws ResourceNotFoundException {
        List<Resource> resources = new ArrayList<>(Messages.length);
        for (Message message : Messages)
        {
            Link selfLink = linkTo(ControllerLinkBuilder.methodOn(MessageController.class).findByAuthor(message.getId())).withSelfRel();
            resources.add(new Resource<Message>(message, selfLink));
        }
        return resources;
    }

    @GetMapping("/")
    public List<Message> findAll() throws ResourceNotFoundException
    {
        return mrepo.findAll();
    }

    @GetMapping("/{txt}")
    public List<Message> search(@PathVariable(name = "txt") String txt) throws ResourceNotFoundException
    {
        return mrepo.findByMtextContaining(txt);
    }

    @GetMapping("/by/{sid}")
    public List<Message> findByAuthor(@PathVariable(name = "sid") Long sid) throws ResourceNotFoundException
    {
        return mrepo.findBySid(sid);
    }

    @PostMapping("/")
    public String saveMessage(@Valid @RequestBody Message message)
    {
        mrepo.save(message);
        return " record saved..";
    }

}




