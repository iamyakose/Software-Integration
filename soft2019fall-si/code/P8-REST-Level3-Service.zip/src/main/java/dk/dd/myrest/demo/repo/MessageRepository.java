package dk.dd.myrest.demo.repo;

import dk.dd.myrest.demo.exceptions.ResourceNotFoundException;
import dk.dd.myrest.demo.model.Message;
import dk.dd.myrest.demo.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MessageRepository extends JpaRepository<Message, Integer>
{
    // custom query to search a message by content
    List<Message> findByMtextContaining(String text);
    // String findBySid(Long sid, Long mid) throws ResourceNotFoundException;
    List<Message> findBySid(Long sid);
}

