package dk.dd.myrest.demo.controller;
/*
 * Maturity Level 3: HATEOAS support
 * persistent DB, two tables
 */

import dk.dd.myrest.demo.exceptions.ResourceNotFoundException;
import dk.dd.myrest.demo.model.Student;
import dk.dd.myrest.demo.repo.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;

@RestController
@RequestMapping("/students")
public class StudentController
{
    @Autowired
    private StudentRepository repo;
    private Object Student;

    @GetMapping("/")
    public List<Student> retrieveAllStudents()
    {
        return (List<Student>) repo.findAll();
    }

    @GetMapping("/{name}")
    public Student findByName(@PathVariable(name = "name") String name) throws ResourceNotFoundException
    {
        return repo.findByName(name);
    }

    @PostMapping("/")
    public String saveStudent(@Valid @RequestBody Student student)
    {
        repo.save(student);
        return " record saved..";
    }

    @DeleteMapping("/{id}")
    public String deleteStudent(@PathVariable(value = "id") long id) throws ResourceNotFoundException
    {
        Integer sid = Integer.valueOf((int)id);
        repo.deleteById(sid);
        return " record deleted...";
    }

    @PutMapping("/{id}")
    public ResponseEntity<Object> updateStudent(@Valid @RequestBody Student student, @PathVariable(value = "id") long id) throws ResourceNotFoundException
    {
        Integer sid = Integer.valueOf((int)id);
        Optional<Student> found = repo.findById(sid);

        if (!found.isPresent())
            return ResponseEntity.badRequest()
                    .header("Custom-Header", "foo")
                    .body("Try again")
                    .notFound().build();
        student.setId(id);
        repo.save(student);
        return   ResponseEntity.ok()
                .header("Custom-Header", "foo")
                .body("Notice the custom header")
                .noContent().build();
    }

    @GetMapping("/{id}/all")
    public MessageController getMessageController()
    {
        return new MessageController();
    }
/*
    @GetMapping(value = "/{id}")
    public Student getStudentById(@PathVariable(name = "id") long id) throws ResourceNotFoundException
    {
        Optional<Student> student = repo.findById(id);
        Student st = student.get();
        Link link = linkTo(StudentController.class).withRel("students");
        student.add(linkTo(StudentController.class).slash(student).withSelfRel());
        st.add(linkTo(methodOn(StudentController.class).getStudentById(id)).withSelfRel());


        //Adding self link employee collection resource
        Link selfLink = ControllerLinkBuilder
                .linkTo(ControllerLinkBuilder
                        .methodOn(StudentController.class).getStudentById(id))
                .withSelfRel();
        return student;
    }

    @GetMapping(value = "/{id}/messages", produces = {"application/hal+json"})
    public Resources<Messages> getMessagesPerStudent(@PathVariable final int id)
    {
        List < Messages > messages = mrepo.getMessages(studid);
        for (final Messages message: messages)
        {
            Link selfLink = linkTo(methodOn(StudentController.class).getMessage(id)).withSelfRel();
            message.add(selfLink);
        }
        Link link = linkTo(methodOn(StudentController.class).getMessagesPerStudent(id)).withSelfRel();
        return new Resources < Messages > (messages, link);
    }
   */


}
