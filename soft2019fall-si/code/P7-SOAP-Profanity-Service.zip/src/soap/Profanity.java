package soap;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Scanner;

@WebService(serviceName = "Profanity")
public class Profanity
{
        @WebMethod
        public String sayHelloWorldFrom(String from)
        {
            String result = "Hello, world, from " + from;
            System.out.println(result);
            return result;
        }

        // A method to read a text file into a hashset
        @WebMethod(operationName = "read")
        public HashSet<String> textToHash(@WebParam(name = "filename") String filename) throws FileNotFoundException {
            HashSet<String> words = new HashSet<>();
            String newwrd;

            Scanner in = new Scanner(new File(filename));

            while(in.hasNext())
            {
                newwrd = in.next();
                words.add(newwrd);
            }
            return words;
        }

        // A method to compare two hashsets and to find their intersection
        @WebMethod(operationName = "search")
        public String search(@WebParam(name = "text") String text) throws FileNotFoundException {
            String test, newword;

            // My two files: a dictionary of profanity words and the text to control
            String dict = "/Users/tdi/IdeaProjects/MySOAP/src/data/dict.txt";
            Scanner ind = new Scanner(new File(dict));
            Scanner ina = new Scanner(new File(text));

            //HashSet<String> bad = new HashSet<>();
            //HashSet<String> all = new HashSet<>();

            HashSet<String> bad = textToHash(dict);
            HashSet<String> all = textToHash(text);
            all.retainAll(bad);

            if (all.isEmpty())
                test = "good language";
            else
                test = "bad language";

            String result = "text: " + text + " dict: " + dict;
            System.out.println("dict: " + dict);
            return result;
        }
}
