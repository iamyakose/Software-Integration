package dk.dd.myrest.demo.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

// Entity object, which is used in ORM, as a RDB table
@Entity
// Lombok will take care to expand the class
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Student
{
    // The ORM will take care to increase it
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    int id;

    @NotNull
    @Size(min = 2, message = "Name has min 2 chars")
    String name;

    @Email
    @NotBlank(message = "mandatory attribute")
    String mail;
}
