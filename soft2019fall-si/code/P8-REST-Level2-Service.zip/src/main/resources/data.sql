insert into student values(10001,'Alice', 'al@mail.dk');
insert into student values(10002,'Bob', 'bo@mail.dk');