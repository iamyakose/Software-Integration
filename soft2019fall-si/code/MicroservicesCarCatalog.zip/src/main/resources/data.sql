INSERT INTO Car VALUES
(1, 'Ferrari', 2009, 250000),
(2, 'Lamborghini', 1985, 50000),
(3, 'Bugatti', 2017, 35000),
(4, 'Renault', 2005, 150000),
(5, 'Mini', 2014, 75000);



