package example;
/*
  @author Dora Di
 */
import org.apache.log4j.BasicConfigurator;
import soap.*;

public class Client
{
  public static void main(String[] argv)
  {
    // to see the logs
    BasicConfigurator.configure();

    String response;
    try
    {
      // connect to the service at its communication port
      ProfanityServiceLocator locator = new ProfanityServiceLocator();
      Profanity_PortType service = locator.getProfanity();

      // consume the operations of the service
      System.out.println(response = service.sayHelloWorldFrom("me"));
      response = service.search("/Users/tdi/IdeaProjects/MySOAPconsumer/src/data/mytext.txt");
      System.out.println(response);
    }
    catch (javax.xml.rpc.ServiceException ex)
    {
      ex.printStackTrace();
    }
    catch (java.rmi.RemoteException ex)
    {
      ex.printStackTrace();
    }
  }
}