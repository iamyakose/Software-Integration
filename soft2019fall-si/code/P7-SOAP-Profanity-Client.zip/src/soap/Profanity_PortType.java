/**
 * Profanity_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package soap;

public interface Profanity_PortType extends java.rmi.Remote {
    public java.lang.Object[] textToHash(java.lang.String filename) throws java.rmi.RemoteException;
    public java.lang.String sayHelloWorldFrom(java.lang.String from) throws java.rmi.RemoteException;
    public java.lang.String search(java.lang.String text) throws java.rmi.RemoteException;
}
